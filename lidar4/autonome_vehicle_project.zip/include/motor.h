void motor_init (void);
void motor_term (void);
void motor_left_set_normalized_speed (double normalized_speed);
void motor_right_set_normalized_speed (double normalized_speed);
